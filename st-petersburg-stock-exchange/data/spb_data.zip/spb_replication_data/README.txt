St. Petersburg Stock Exchange (SPSE), 1865-1917 — data
======================================================
From Goetzmann & Huang, "Momentum in Imperial Russia" (JFE 130, 2018, 579-591).
Data collected by W. Goetzmann, C. Cabolis, P. Radchenko (Yale ICF).

Files
-----
  St_Petersburg_data_individual_securities.xlsx  Master workbook. Sheets:
      '1865-1917'  security-level monthly prices (Number, Cyrillic/translit names,
                   Sector, Founded, Par; 3 price cells per month; blank/M = missing)
      'Names'      Number -> company name (English + Cyrillic) + Industry key
      'dividends all years'  annual dividends by security, % of par, ~1885-1915
  St_Petersburg_Industry_Returns.xlsx  Monthly industry return & cumulative-return
                   indexes, 40 industries, 1865-1917 (+ N companies, summary stats).
  market_and_momentum_indexes.xlsx  The paper's own series: sheet 'mkt' = monthly
                   equal-weighted market return + cumulative index; momentum tables.

NOTE ON RETURNS: these are PRICE / capital-appreciation returns. Imperial-Russian
dividend data is annual and sparse (1885-1915), so the indexes track price, not
total return (unlike the London IMM series).

USAGE: academic research only; not for commercial use or redistribution without
authorization of the authors and the Yale International Center for Finance.
