"""
shanghai_bubble_analysis.py
============================
Apply Goetzmann-Manninen-Tyler (2026) boom/crash/bubble detection methodology
to annual industry-level data from the Shanghai Stock Exchange, 1870-1940.

Reads:
  - shanghai_industry_indexes.csv  (produced by build_industry_indexes.py)

Outputs (figures/ and tables/ subdirectories):
  fig1_cumulative_indices.png
  fig2_3year_booms.png
  fig3_1year_booms.png
  fig4_3year_crashes.png
  fig5_1year_crashes.png
  fig6_event_study.png
  fig7_conditional_distributions.png
  fig8_event_timeline.png
  tables/table_boom_episodes.csv
  tables/table_crash_episodes.csv
  tables/table_bubble_events.csv
  tables/table_sector_summary.csv
"""

import csv
import math
import os
from collections import defaultdict

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.ticker as mticker
import numpy as np

BASE      = os.path.dirname(os.path.abspath(__file__))
DATA_FILE = os.path.join(BASE, 'shanghai_industry_indexes.csv')
FIG_DIR   = os.path.join(BASE, 'figures')
TAB_DIR   = os.path.join(BASE, 'tables')
os.makedirs(FIG_DIR, exist_ok=True)
os.makedirs(TAB_DIR, exist_ok=True)

# ═══════════════════════════════════════════════════════════════════════
# 1. LOAD AND PREPARE DATA
# ═══════════════════════════════════════════════════════════════════════

print("Loading Shanghai industry indexes...")

raw            = defaultdict(dict)   # sector -> {year: return}
all_years_set  = set()
all_sectors_set = set()

with open(DATA_FILE) as f:
    reader = csv.DictReader(f)
    for row in reader:
        year   = int(row['year'])
        sector = row['sector'].strip()
        # Prefer total return (cap appreciation + dividend income)
        for col_name in ('ew_total', 'ew_cap_ap'):
            val = row.get(col_name, '').strip()
            if val and val not in ('', 'None', 'nan', 'NaN'):
                try:
                    r = float(val)
                    if abs(r) < 10.0:          # drop extreme implausible values
                        raw[sector][year] = r
                        break
                except ValueError:
                    pass
        all_years_set.add(year)
        all_sectors_set.add(sector)

all_years = sorted(all_years_set)
T         = len(all_years)
year_to_t = {y: i for i, y in enumerate(all_years)}

# Filter: require at least 15 annual observations
MIN_OBS   = 15
industries = sorted(
    s for s in all_sectors_set
    if len(raw[s]) >= MIN_OBS
)

print(f"  {T} annual observations ({all_years[0]}–{all_years[-1]})")
print(f"  {len(industries)} sectors with ≥{MIN_OBS} years of data:")
for ind in industries:
    n = len(raw[ind])
    yrs = sorted(raw[ind].keys())
    print(f"    {ind:35s}  {n:3d} obs  ({yrs[0]}–{yrs[-1]})")

# Return arrays indexed by t ∈ [0, T-1]; None where missing
returns = {ind: [raw[ind].get(y) for y in all_years] for ind in industries}

# Equal-weighted market return across available sectors each year
market_ret = []
for t in range(T):
    rets_t = [returns[ind][t] for ind in industries if returns[ind][t] is not None]
    market_ret.append(sum(rets_t) / len(rets_t) if rets_t else None)

# ═══════════════════════════════════════════════════════════════════════
# 2. BUILD CUMULATIVE PRICE LEVELS
# ═══════════════════════════════════════════════════════════════════════

def build_levels(ret_list):
    """Cumulative price index from return list. Length = T+1; levels[t+1] is end of year t."""
    levels = [1.0]
    for r in ret_list:
        if r is not None and abs(r) < 5.0:
            levels.append(levels[-1] * (1 + r))
        else:
            levels.append(levels[-1])   # carry forward on missing/extreme
    return levels

mkt_level  = build_levels(market_ret)
ind_levels = {ind: build_levels(returns[ind]) for ind in industries}

print(f"\n  Market cumulative return ({all_years[0]}–{all_years[-1]}): {mkt_level[-1]:.2f}×")

# ═══════════════════════════════════════════════════════════════════════
# 3. FIGURE 1 — Cumulative Sector Indices (log scale)
# ═══════════════════════════════════════════════════════════════════════

print("\nFigure 1: Cumulative sector indices...")

colors = plt.cm.tab20.colors
fig, ax = plt.subplots(figsize=(12, 7))
ax.plot(all_years, [mkt_level[t + 1] for t in range(T)],
        'k-', linewidth=2.5, label='Market (EW)', zorder=5)
for i, ind in enumerate(industries):
    lvls = [ind_levels[ind][t + 1] for t in range(T)]
    ax.plot(all_years, lvls, color=colors[i % 20], linewidth=1.2, alpha=0.85, label=ind)
ax.set_yscale('log')
ax.set_xlabel('Year')
ax.set_ylabel('Cumulative Return Index (log scale, base year = 1)')
ax.set_title('Shanghai Stock Exchange: Sector Cumulative Return Indices, 1870–1940')
ax.legend(fontsize=7, ncol=2, loc='upper left')
ax.grid(True, alpha=0.3)
plt.tight_layout()
plt.savefig(os.path.join(FIG_DIR, 'fig1_cumulative_indices.png'), dpi=150)
plt.close()
print("  Saved fig1_cumulative_indices.png")

# ═══════════════════════════════════════════════════════════════════════
# 4. BOOM / CRASH DETECTION — AGGREGATE MARKET
# ═══════════════════════════════════════════════════════════════════════

def count_episodes(levels, thresholds, lookback, forward_horizons):
    """
    Count boom episodes and subsequent outcomes (aggregate or single series).
    levels          : cumulative price index, length T+1; levels[t+1] = end of year t
    lookback        : lookback window in years
    forward_horizons: forward window sizes in years
    """
    results = {}
    for thresh in thresholds:
        episodes = []
        for t in range(lookback, T):
            prior_ret = levels[t + 1] / levels[t + 1 - lookback] - 1
            if prior_ret >= thresh:
                episodes.append(t)
        further_booms  = {h: 0 for h in forward_horizons}
        full_reversals = {h: 0 for h in forward_horizons}
        n_available    = {h: 0 for h in forward_horizons}
        for t in episodes:
            for h in forward_horizons:
                if t + h < T:
                    n_available[h] += 1
                    fwd = levels[t + 1 + h] / levels[t + 1] - 1
                    if fwd >= thresh:
                        further_booms[h] += 1
                    if fwd <= -thresh / (1 + thresh):
                        full_reversals[h] += 1
        results[thresh] = {
            'n_episodes':    len(episodes),
            'further_booms': further_booms,
            'full_reversals': full_reversals,
            'n_available':   n_available,
            'episodes':      episodes,
        }
    return results


def count_crash_episodes(levels, thresholds, lookback, forward_horizons):
    """Count crash episodes and subsequent recovery / further-decline outcomes."""
    results = {}
    for thresh in thresholds:
        episodes = []
        for t in range(lookback, T):
            prior_ret = levels[t + 1] / levels[t + 1 - lookback] - 1
            if prior_ret <= -thresh:
                episodes.append(t)
        recoveries       = {h: 0 for h in forward_horizons}
        further_declines = {h: 0 for h in forward_horizons}
        n_available      = {h: 0 for h in forward_horizons}
        for t in episodes:
            for h in forward_horizons:
                if t + h < T:
                    n_available[h] += 1
                    fwd    = levels[t + 1 + h] / levels[t + 1] - 1
                    needed = thresh / (1 - thresh)
                    if fwd >= needed:
                        recoveries[h] += 1
                    if fwd <= -thresh:
                        further_declines[h] += 1
        results[thresh] = {
            'n_episodes':      len(episodes),
            'recoveries':      recoveries,
            'further_declines': further_declines,
            'n_available':     n_available,
            'episodes':        episodes,
        }
    return results


print("\n═══ Aggregate Market Analysis ═══")
fwd_h    = [1, 3, 5]          # annual equivalents of 12, 36, 60 months

boom_3y  = count_episodes(mkt_level, [0.50, 0.75, 1.00], 3, fwd_h)
boom_1y  = count_episodes(mkt_level, [0.25, 0.50],        1, fwd_h)
crash_3y = count_crash_episodes(mkt_level, [0.20, 0.30, 0.40, 0.50], 3, fwd_h)
crash_1y = count_crash_episodes(mkt_level, [0.20, 0.30, 0.40, 0.50], 1, fwd_h)

for label, results, thresholds in [
    ("3-Year Booms",   boom_3y,  [0.50, 0.75, 1.00]),
    ("1-Year Booms",   boom_1y,  [0.25, 0.50]),
    ("3-Year Crashes", crash_3y, [0.20, 0.30, 0.40, 0.50]),
    ("1-Year Crashes", crash_1y, [0.20, 0.30, 0.40, 0.50]),
]:
    print(f"\n{label}:")
    for thresh in thresholds:
        r  = results[thresh]
        na = r['n_available']
        sign = '>=' if 'Boom' in label else '<='
        print(f"  {sign} {'+' if 'Boom' in label else '-'}{thresh:.0%}  "
              f"n={r['n_episodes']}  "
              f"| fwd1y={r.get('further_booms', r.get('recoveries', {})).get(1,0)}"
              f"/{na.get(1,0)}  "
              f"fwd3y={r.get('further_booms', r.get('recoveries', {})).get(3,0)}"
              f"/{na.get(3,0)}  "
              f"fwd5y={r.get('further_booms', r.get('recoveries', {})).get(5,0)}"
              f"/{na.get(5,0)}")

# ═══════════════════════════════════════════════════════════════════════
# 5. INDUSTRY-LEVEL EVENT IDENTIFICATION
# ═══════════════════════════════════════════════════════════════════════

print("\n═══ Industry-Level Events ═══")

def identify_booms_greenwood(ind_levels, mkt_levels):
    """
    Greenwood et al. (2019) definition adapted for annual data:
      - Raw 2-year return >= 100%
      - Market-adjusted 2-year return >= 100%
      - Raw 5-year return >= 50% (skipped if <5 years available)
    No double-counting within 2 years of a boom.
    """
    booms   = []
    blocked = set()
    for ind in industries:
        levels = ind_levels[ind]
        for t in range(2, T):
            if (ind, t) in blocked:
                continue
            raw_2y = levels[t + 1] / levels[t - 1] - 1
            if raw_2y < 1.0:
                continue
            mkt_2y = mkt_levels[t + 1] / mkt_levels[t - 1] - 1
            if mkt_2y <= -1.0:
                continue
            excess_2y = (1 + raw_2y) / (1 + mkt_2y) - 1
            if excess_2y < 1.0:
                continue
            if t >= 5:
                raw_5y = levels[t + 1] / levels[t - 4] - 1
                if raw_5y < 0.5:
                    continue
            booms.append((ind, t))
            for dt in range(1, 3):
                blocked.add((ind, t + dt))
    return booms


def identify_simple_events(ind_levels, thresh_boom=1.0, thresh_crash=-0.5):
    """1-year threshold boom/crash; no double-counting within 1 year."""
    booms         = []
    crashes       = []
    boom_blocked  = set()
    crash_blocked = set()
    for ind in industries:
        levels = ind_levels[ind]
        for t in range(1, T):
            ret_1y = levels[t + 1] / levels[t] - 1
            if (ind, t) not in boom_blocked and ret_1y >= thresh_boom:
                booms.append((ind, t))
                boom_blocked.add((ind, t + 1))
            if (ind, t) not in crash_blocked and ret_1y <= thresh_crash:
                crashes.append((ind, t))
                crash_blocked.add((ind, t + 1))
    return booms, crashes


booms_green              = identify_booms_greenwood(ind_levels, mkt_level)
booms_simple, crashes_simple = identify_simple_events(ind_levels,
                                                       thresh_boom=1.0,
                                                       thresh_crash=-0.5)
booms_50, crashes_30     = identify_simple_events(ind_levels,
                                                   thresh_boom=0.50,
                                                   thresh_crash=-0.30)

# Bubbles: Greenwood boom followed by ≥40% decline from post-boom peak within 2 years
bubbles = []
for ind, t_boom in booms_green:
    levels = ind_levels[ind]
    peak = levels[t_boom + 1]
    for dt in range(1, 3):
        if t_boom + dt < T:
            peak = max(peak, levels[t_boom + dt + 1])
    for dt in range(1, 3):
        t_fwd = t_boom + dt
        if t_fwd < T:
            decline = levels[t_fwd + 1] / peak - 1
            if decline <= -0.40:
                bubbles.append((ind, t_boom, t_fwd))
                break

print(f"\nGreenwood booms (2-year doubling, mkt-adj): {len(booms_green)}")
for ind, t in booms_green:
    raw_2y = ind_levels[ind][t + 1] / ind_levels[ind][t - 1] - 1
    print(f"  {all_years[t]}  {ind:<35s}  raw 2y: {raw_2y:+.1%}")

print(f"\nGreenwood bubbles (boom + ≥40% peak decline within 2 years): {len(bubbles)}")
for ind, tb, tc in bubbles:
    print(f"  {ind}: boom {all_years[tb]}, crash {all_years[tc]}")

print(f"\nSimple booms (≥100%, 1y):   {len(booms_simple)}")
for ind, t in booms_simple:
    print(f"  {all_years[t]}  {ind}")

print(f"Simple crashes (≤−50%, 1y): {len(crashes_simple)}")
for ind, t in crashes_simple:
    print(f"  {all_years[t]}  {ind}")

print(f"\nLower-threshold booms (≥50%, 1y):   {len(booms_50)}")
for ind, t in booms_50:
    raw_1y = ind_levels[ind][t + 1] / ind_levels[ind][t] - 1
    print(f"  {all_years[t]}  {ind:<35s}  {raw_1y:+.1%}")

print(f"Lower-threshold crashes (≤−30%, 1y): {len(crashes_30)}")
for ind, t in crashes_30:
    raw_1y = ind_levels[ind][t + 1] / ind_levels[ind][t] - 1
    print(f"  {all_years[t]}  {ind:<35s}  {raw_1y:+.1%}")

# ═══════════════════════════════════════════════════════════════════════
# 6. BAR CHART FIGURES (Figures 2–5)
# ═══════════════════════════════════════════════════════════════════════

print("\nGenerating boom/crash bar charts (Figures 2–5)...")

def plot_boom_bars(results, thresholds, fwd_h, title, filename):
    fig, ax = plt.subplots(figsize=(10, 6))
    bar_w        = 0.12
    shades_green = ['#a8d5a2', '#5cb85c', '#2d6a2d']
    shades_red   = ['#e8a0a0', '#d9534f', '#a02020']
    for i, thresh in enumerate(thresholds):
        r = results[thresh]
        x = i * 2.5
        for j, h in enumerate(fwd_h):
            fb = r['further_booms'][h]
            fr = r['full_reversals'][h]
            ax.bar(x - 0.5 + j * bar_w, fb, bar_w, color=shades_green[j], edgecolor='white')
            ax.bar(x + 0.5 + j * bar_w, fr, bar_w, color=shades_red[j],   edgecolor='white')
            if fb > 0:
                ax.text(x - 0.5 + j * bar_w, fb + 0.05, str(fb),
                        ha='center', va='bottom', fontsize=7)
            if fr > 0:
                ax.text(x + 0.5 + j * bar_w, fr + 0.05, str(fr),
                        ha='center', va='bottom', fontsize=7)
    ax.set_xticks([i * 2.5 for i in range(len(thresholds))])
    ax.set_xticklabels([f'>= +{int(t*100)}%\n(n = {results[t]["n_episodes"]})' for t in thresholds])
    ax.set_ylabel('Count of episodes')
    ax.set_title(title)
    ax.legend(['Further boom 1y', 'Further boom 3y', 'Further boom 5y',
               'Full reversal 1y', 'Full reversal 3y', 'Full reversal 5y'],
              fontsize=8, loc='upper right')
    plt.tight_layout()
    plt.savefig(os.path.join(FIG_DIR, filename), dpi=150)
    plt.close()
    print(f"  Saved {filename}")


def plot_crash_bars(results, thresholds, fwd_h, title, filename):
    fig, ax = plt.subplots(figsize=(10, 6))
    bar_w        = 0.12
    shades_green = ['#a8d5a2', '#5cb85c', '#2d6a2d']
    shades_red   = ['#e8a0a0', '#d9534f', '#a02020']
    for i, thresh in enumerate(thresholds):
        r = results[thresh]
        x = i * 2.5
        for j, h in enumerate(fwd_h):
            rc = r['recoveries'][h]
            fd = r['further_declines'][h]
            ax.bar(x - 0.5 + j * bar_w, rc, bar_w, color=shades_green[j], edgecolor='white')
            ax.bar(x + 0.5 + j * bar_w, fd, bar_w, color=shades_red[j],   edgecolor='white')
            if rc > 0:
                ax.text(x - 0.5 + j * bar_w, rc + 0.05, str(rc),
                        ha='center', va='bottom', fontsize=7)
            if fd > 0:
                ax.text(x + 0.5 + j * bar_w, fd + 0.05, str(fd),
                        ha='center', va='bottom', fontsize=7)
    ax.set_xticks([i * 2.5 for i in range(len(thresholds))])
    ax.set_xticklabels([f'<= -{int(t*100)}%\n(n = {results[t]["n_episodes"]})' for t in thresholds])
    ax.set_ylabel('Count of episodes')
    ax.set_title(title)
    ax.legend(['Full recovery 1y', 'Full recovery 3y', 'Full recovery 5y',
               'Further decline 1y', 'Further decline 3y', 'Further decline 5y'],
              fontsize=8, loc='upper right')
    plt.tight_layout()
    plt.savefig(os.path.join(FIG_DIR, filename), dpi=150)
    plt.close()
    print(f"  Saved {filename}")


plot_boom_bars(boom_3y, [0.50, 0.75, 1.00], fwd_h,
               'Conditional Outcomes After 3-Year Booms\nShanghai Market 1870–1940',
               'fig2_3year_booms.png')
plot_boom_bars(boom_1y, [0.25, 0.50], fwd_h,
               'Conditional Outcomes After 1-Year Booms\nShanghai Market 1870–1940',
               'fig3_1year_booms.png')
plot_crash_bars(crash_3y, [0.20, 0.30, 0.40, 0.50], fwd_h,
                'Conditional Outcomes After 3-Year Crashes\nShanghai Market 1870–1940',
                'fig4_3year_crashes.png')
plot_crash_bars(crash_1y, [0.20, 0.30, 0.40, 0.50], fwd_h,
                'Conditional Outcomes After 1-Year Crashes\nShanghai Market 1870–1940',
                'fig5_1year_crashes.png')

# ═══════════════════════════════════════════════════════════════════════
# 7. EVENT STUDY (Figure 6)
# ═══════════════════════════════════════════════════════════════════════

print("\nFigure 6: Event study...")

def event_study_annual(events, ind_levels, mkt_levels, before=3, after=5):
    """Average normalised price paths around events (annual data)."""
    raw_paths    = []
    excess_paths = []
    for ind, t_event in events:
        levels   = ind_levels[ind]
        base     = levels[t_event + 1]
        mkt_base = mkt_levels[t_event + 1]
        if base <= 0 or mkt_base <= 0:
            continue
        ok = True
        raw_p = []
        exc_p = []
        for dt in range(-before, after + 1):
            t = t_event + dt
            if 0 <= t < T:
                raw_val = levels[t + 1] / base
                mkt_val = mkt_levels[t + 1] / mkt_base
                raw_p.append(raw_val)
                exc_p.append(raw_val / mkt_val if mkt_val > 0 else raw_val)
            else:
                ok = False
                break
        if ok:
            raw_paths.append(raw_p)
            excess_paths.append(exc_p)
    return raw_paths, excess_paths


def plot_event_study(boom_events, crash_events, ind_levels, mkt_levels,
                     title_prefix, filename, before=3, after=5):
    fig, axes = plt.subplots(1, 2, figsize=(14, 5))
    x = list(range(-before, after + 1))
    boom_raw,  boom_exc  = event_study_annual(boom_events,  ind_levels, mkt_levels, before, after)
    crash_raw, crash_exc = event_study_annual(crash_events, ind_levels, mkt_levels, before, after)
    for ax_idx, (boom_paths, crash_paths, label) in enumerate([
        (boom_raw,  crash_raw,  'Raw returns'),
        (boom_exc,  crash_exc,  'Excess of market'),
    ]):
        ax = axes[ax_idx]
        for paths, color, lbl in [
            (boom_paths,  'green', f'Run-up   (N={len(boom_paths)})'),
            (crash_paths, 'red',   f'Run-down (N={len(crash_paths)})'),
        ]:
            if paths:
                arr  = np.array(paths)
                mean = np.mean(arr, axis=0)
                se   = np.std(arr,  axis=0) / np.sqrt(len(paths))
                ax.plot(x, mean, color=color, linewidth=2, label=lbl)
                ax.fill_between(x, mean - 1.96 * se, mean + 1.96 * se,
                                alpha=0.2, color=color)
        ax.axhline(1.0, color='gray', linestyle='--', alpha=0.5)
        ax.axvline(0,   color='gray', linestyle='--', alpha=0.5)
        ax.set_xlabel('Years relative to event (t=0 at trigger year)')
        ax.set_ylabel('Normalized level (t=0 = 1.0)')
        ax.set_title(f'{title_prefix} — {label}')
        ax.legend(fontsize=9)
    plt.tight_layout()
    plt.savefig(os.path.join(FIG_DIR, filename), dpi=150)
    plt.close()
    print(f"  Saved {filename}")


plot_event_study(booms_50, crashes_30, ind_levels, mkt_level,
                 'Shanghai Industries 1870–1940\n≥50% run-up / ≤−30% run-down',
                 'fig6_event_study.png',
                 before=3, after=5)

# ═══════════════════════════════════════════════════════════════════════
# 8. CONDITIONAL DISTRIBUTIONS (Figure 7)
# ═══════════════════════════════════════════════════════════════════════

print("\nFigure 7: Conditional distributions...")

uncond_raw = []
uncond_exc = []
for ind in industries:
    levels = ind_levels[ind]
    for t in range(T - 1):
        fwd     = levels[t + 2] / levels[t + 1] - 1
        mkt_fwd = mkt_level[t + 2] / mkt_level[t + 1] - 1
        if abs(fwd) < 2.0:
            uncond_raw.append(fwd)
            if mkt_fwd > -1:
                uncond_exc.append((1 + fwd) / (1 + mkt_fwd) - 1)

cond_raw_boom50 = []
for ind, t_event in booms_50:
    levels = ind_levels[ind]
    if t_event + 1 < T:
        fwd = levels[t_event + 2] / levels[t_event + 1] - 1
        if abs(fwd) < 2.0:
            cond_raw_boom50.append(fwd)

cond_raw_crash30 = []
for ind, t_event in crashes_30:
    levels = ind_levels[ind]
    if t_event + 1 < T:
        fwd = levels[t_event + 2] / levels[t_event + 1] - 1
        if abs(fwd) < 2.0:
            cond_raw_crash30.append(fwd)

print(f"  Unconditional returns:  N={len(uncond_raw)}")
print(f"  Post-boom (≥50%):       N={len(cond_raw_boom50)}")
print(f"  Post-crash (≤−30%):     N={len(cond_raw_crash30)}")
if uncond_raw:
    print(f"  Unconditional mean: {np.mean(uncond_raw):.3f}")
if cond_raw_boom50:
    print(f"  Post-boom mean:     {np.mean(cond_raw_boom50):.3f}")
if cond_raw_crash30:
    print(f"  Post-crash mean:    {np.mean(cond_raw_crash30):.3f}")

fig, axes = plt.subplots(1, 2, figsize=(14, 5))
clip = (-1.0, 2.0)
bins = np.linspace(clip[0], clip[1], 50)

for ax, cond, cond_label, title in [
    (axes[0], cond_raw_boom50,  'Post-boom (≥50%)',
     'Post-boom vs Unconditional\n1-Year Forward Returns, Shanghai'),
    (axes[1], cond_raw_crash30, 'Post-crash (≤−30%)',
     'Post-crash vs Unconditional\n1-Year Forward Returns, Shanghai'),
]:
    unc = [x for x in uncond_raw if clip[0] <= x <= clip[1]]
    con = [x for x in cond       if clip[0] <= x <= clip[1]]
    if unc:
        ax.hist(unc, bins=bins, density=True, alpha=0.5, color='steelblue',
                label=f'Unconditional (N={len(unc)})')
        ax.axvline(np.mean(unc), color='steelblue', linestyle='--', linewidth=1.5)
    if con:
        ax.hist(con, bins=bins, density=True, alpha=0.5, color='indianred',
                label=f'{cond_label} (N={len(con)})')
        ax.axvline(np.mean(con), color='indianred', linestyle='--', linewidth=1.5)
    ax.set_xlabel('1-year forward return')
    ax.set_ylabel('Density')
    ax.set_title(title)
    ax.legend(fontsize=9)
    ax.xaxis.set_major_formatter(mticker.PercentFormatter(xmax=1.0))

plt.tight_layout()
plt.savefig(os.path.join(FIG_DIR, 'fig7_conditional_distributions.png'), dpi=150)
plt.close()
print("  Saved fig7_conditional_distributions.png")

# ═══════════════════════════════════════════════════════════════════════
# 9. EVENT TIMELINE (Figure 8)
# ═══════════════════════════════════════════════════════════════════════

print("\nFigure 8: Event timeline...")

y_pos = {ind: i for i, ind in enumerate(industries)}
all_events = (
    [(all_years[t], ind, 'Greenwood Boom', '^', 'green', 100)  for ind, t in booms_green]    +
    [(all_years[t], ind, 'Simple Boom',    '^', 'steelblue', 64) for ind, t in booms_50]      +
    [(all_years[t], ind, 'Simple Crash',   'v', 'indianred', 64) for ind, t in crashes_30]    +
    [(all_years[tb], ind, 'Bubble',        '*', 'black', 144)    for ind, tb, _ in bubbles]
)

fig, ax = plt.subplots(figsize=(14, max(6, len(industries))))
handles_seen = {}
for year, ind, label, marker, color, size in all_events:
    y = y_pos.get(ind, -1)
    sc = ax.scatter(year, y, marker=marker, c=color, s=size, zorder=5,
                    label=label if label not in handles_seen else '')
    if label not in handles_seen:
        handles_seen[label] = sc

ax.set_yticks(list(y_pos.values()))
ax.set_yticklabels(list(y_pos.keys()), fontsize=9)
ax.set_xlabel('Year')
ax.set_title('Boom and Crash Events by Sector, Shanghai Stock Exchange 1870–1940')
if handles_seen:
    ax.legend(handles=list(handles_seen.values()),
              labels=list(handles_seen.keys()), fontsize=9, loc='upper left')
ax.grid(True, alpha=0.3, axis='x')
plt.tight_layout()
plt.savefig(os.path.join(FIG_DIR, 'fig8_event_timeline.png'), dpi=150)
plt.close()
print("  Saved fig8_event_timeline.png")

# ═══════════════════════════════════════════════════════════════════════
# 10. SAVE TABLES
# ═══════════════════════════════════════════════════════════════════════

print("\nSaving tables...")

with open(os.path.join(TAB_DIR, 'table_boom_episodes.csv'), 'w', newline='') as f:
    w = csv.writer(f)
    w.writerow(['Definition', 'Year', 'Sector', 'Lookback_Return'])
    for ind, t in booms_green:
        r = ind_levels[ind][t + 1] / ind_levels[ind][t - 1] - 1
        w.writerow(['Greenwood (2yr 100%)', all_years[t], ind, f'{r:.3f}'])
    for ind, t in booms_simple:
        r = ind_levels[ind][t + 1] / ind_levels[ind][t] - 1
        w.writerow(['Simple (>=100%)', all_years[t], ind, f'{r:.3f}'])
    for ind, t in booms_50:
        r = ind_levels[ind][t + 1] / ind_levels[ind][t] - 1
        w.writerow(['Simple (>=50%)', all_years[t], ind, f'{r:.3f}'])

with open(os.path.join(TAB_DIR, 'table_crash_episodes.csv'), 'w', newline='') as f:
    w = csv.writer(f)
    w.writerow(['Definition', 'Year', 'Sector', 'Lookback_Return'])
    for ind, t in crashes_simple:
        r = ind_levels[ind][t + 1] / ind_levels[ind][t] - 1
        w.writerow(['Simple (<=-50%)', all_years[t], ind, f'{r:.3f}'])
    for ind, t in crashes_30:
        r = ind_levels[ind][t + 1] / ind_levels[ind][t] - 1
        w.writerow(['Simple (<=-30%)', all_years[t], ind, f'{r:.3f}'])

with open(os.path.join(TAB_DIR, 'table_bubble_events.csv'), 'w', newline='') as f:
    w = csv.writer(f)
    w.writerow(['Sector', 'Boom_Year', 'Crash_Year', 'Post_Peak_Decline'])
    for ind, tb, tc in bubbles:
        peak    = max(ind_levels[ind][t + 1] for t in range(tb, min(tc + 2, T)))
        decline = ind_levels[ind][tc + 1] / peak - 1
        w.writerow([ind, all_years[tb], all_years[tc], f'{decline:.3f}'])

with open(os.path.join(TAB_DIR, 'table_sector_summary.csv'), 'w', newline='') as f:
    w = csv.writer(f)
    w.writerow(['Sector', 'N_Years', 'First_Year', 'Last_Year',
                'Ann_Return', 'Cumulative_Return'])
    for ind in industries:
        rets = [r for r in returns[ind] if r is not None]
        yrs  = [all_years[t] for t, r in enumerate(returns[ind]) if r is not None]
        if rets:
            n_obs   = len(rets)
            ann_ret = ind_levels[ind][-1] ** (1 / n_obs) - 1
            w.writerow([ind, n_obs, min(yrs), max(yrs),
                        f'{ann_ret:.4f}', f'{ind_levels[ind][-1]:.4f}'])

# Aggregate boom/crash summary table
with open(os.path.join(TAB_DIR, 'table_aggregate_summary.csv'), 'w', newline='') as f:
    w = csv.writer(f)
    w.writerow(['Type', 'Window', 'Threshold', 'N_episodes',
                'N_avail_1y', 'Outcome_1y', 'N_avail_3y', 'Outcome_3y',
                'N_avail_5y', 'Outcome_5y'])
    for results, thresholds, rtype, window, outcome_key in [
        (boom_3y,  [0.50, 0.75, 1.00], 'Boom',  '3yr', 'further_booms'),
        (boom_1y,  [0.25, 0.50],        'Boom',  '1yr', 'further_booms'),
        (crash_3y, [0.20, 0.30, 0.40, 0.50], 'Crash', '3yr', 'recoveries'),
        (crash_1y, [0.20, 0.30, 0.40, 0.50], 'Crash', '1yr', 'recoveries'),
    ]:
        for thresh in thresholds:
            r = results[thresh]
            w.writerow([rtype, window, f'{thresh:.0%}', r['n_episodes'],
                        r['n_available'].get(1, 0), r[outcome_key].get(1, 0),
                        r['n_available'].get(3, 0), r[outcome_key].get(3, 0),
                        r['n_available'].get(5, 0), r[outcome_key].get(5, 0)])

print("  Saved all tables")
print("\n═══ DONE ═══")
print(f"Figures: {FIG_DIR}")
print(f"Tables:  {TAB_DIR}")
