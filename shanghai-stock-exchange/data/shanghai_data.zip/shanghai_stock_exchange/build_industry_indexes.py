#!/usr/bin/env python3
"""
Build Shanghai Stock Exchange Industry Return Indexes (1870-1940)

Reads annual company-level stock data from:
    SHARES VALUES IN $(final version 2).xls
and constructs equal-weighted (EW) and value-weighted (VW) industry return
indexes across 10 harmonized sectors.

Outputs:
    shanghai_industry_indexes.csv  -- annual industry-level returns
    shanghai_company_returns.csv   -- company-level panel (for debugging)
    shanghai_validation.csv        -- comparison with Shanghai.csv
"""

import pandas as pd
import numpy as np
import re
import os
import warnings

warnings.filterwarnings('ignore')

# -- Paths -----------------------------------------------------------------

WORK_DIR = os.path.dirname(os.path.abspath(__file__))
XLS_FILE = os.path.join(WORK_DIR, 'SHARES VALUES IN $(final version 2).xls')
VALIDATION_FILE = os.path.join(WORK_DIR, 'Shanghai.csv')
OUTPUT_INDUSTRY = os.path.join(WORK_DIR, 'shanghai_industry_indexes.csv')
OUTPUT_COMPANY = os.path.join(WORK_DIR, 'shanghai_company_returns.csv')
OUTPUT_VALIDATION = os.path.join(WORK_DIR, 'shanghai_validation.csv')

# -- Sector Harmonization -------------------------------------------------

SECTOR_MAP = {
    'bank':                        'Banking',
    'banks':                       'Banking',
    'banks finance companies':     'Banking',
    'banks, finance companies':    'Banking',
    'trusts':                      'Banking',
    'finance companies':           'Banking',
    'shipping':                    'Shipping',
    'tugs & cargo boats':          'Shipping',
    'tugs and cargo boats':        'Shipping',
    'cargo boats':                 'Shipping',
    'insurance':                   'Insurance',
    'insurance (marine)':          'Insurance',
    'insurance (fire)':            'Insurance',
    'docks':                       'Docks & Wharves',
    'docks wharves and godowns':   'Docks & Wharves',
    'docks, wharves and godowns':  'Docks & Wharves',
    'docks wharves transport':     'Docks & Wharves',
    'docks, wharves, transport':   'Docks & Wharves',
    'docks, wharves transport':    'Docks & Wharves',
    'wharfs':                      'Docks & Wharves',
    'mining':                      'Mining',
    'plantations':                 'Plantations',
    'planatations':                'Plantations',
    'cotton':                      'Cotton',
    'industrial':                  'Industrial',
    'gas':                         'Industrial',
    'utilities':                   'Industrial',
    'lands':                       'Real Estate',
    'lands and hotels':            'Real Estate',
    'hotels':                      'Real Estate',
    'miscellaneous':               'Miscellaneous',
    'stores':                      'Miscellaneous',
    'sugar companies':             'Miscellaneous',
    'greyhounds':                  'Miscellaneous',
    'bonds and preferences':       'Miscellaneous',
}


def harmonize_sector(raw):
    """Map a raw sector label to one of 10 harmonized sectors."""
    if raw is None or (isinstance(raw, float) and np.isnan(raw)):
        return None
    cleaned = str(raw).strip().lower().rstrip()
    if not cleaned:
        return None
    if cleaned in SECTOR_MAP:
        return SECTOR_MAP[cleaned]
    # Partial-match fallback
    for key, val in SECTOR_MAP.items():
        if key in cleaned or cleaned in key:
            return val
    return 'Miscellaneous'


# -- Fine-Grained Subsector Classification --------------------------------

# Rules checked in priority order (first match wins).
# Each rule: (fine_sector, keywords_list, broad_sector_filter_or_None)
# If broad_sector_filter is set, the rule only applies to companies in that
# broad sector.  Keywords are matched against the lowercased company name
# OR raw sector label.
_SUBSECTOR_RULES = [
    # Specific matches first
    ('Tin Mining',          ['tin mining', 'tin &'],                       'Mining'),
    ('Gold Mining',         ['gold'],                                     'Mining'),
    ('Fire Insurance',      ['insurance (fire)'],                          None),
    ('Fire Insurance',      ['fire insur', 'fire ins'],                    'Insurance'),
    ('Marine Insurance',    ['insurance (marine)'],                        None),
    ('Marine Insurance',    ['marine insur', 'marine ins'],                'Insurance'),
    ('Tugs & Lighters',    ['tug', 'lighter', 'tow boat'],               'Shipping'),
    ('Steam Navigation',   ['steam nav', 's.n.co', 'steamship',
                             'steamboat', 'steamer', 'shipping co'],      'Shipping'),
    ('Wharves & Godowns',  ['wharf', 'godown'],                           'Docks & Wharves'),
    ('Docks & Shipbuilding', ['dock', 'shipbuilding', 'engineering works'], 'Docks & Wharves'),
    ('Trust & Investment',  ['trust', 'invest', 'finance corp',
                              'loan &', 'loan co'],                       'Banking'),
    ('Cotton & Textiles',  ['cotton', 'textile', 'weav', 'fibre'],        None),
    ('Rubber Plantations', ['rubber'],                                     'Plantations'),
    ('Other Plantations',  ['coffee', 'tea ', 'tapioca', 'tobacco'],      'Plantations'),
    ('Utilities',          ['gas co', 'du gaz', 'waterworks', 'electric',
                             'telephone', 'power co', 'power ld'],        None),
    ('Tobacco',            ['tobacco', 'cigarette'],                       None),
    ('Food & Beverage',    ['brewery', 'flour', 'rice mill',
                             'cold storage', 'dairy', 'refrigerat'],      None),
    ('Sugar',              ['sugar'],                                      None),
    ('Cement & Building',  ['cement', 'tile works'],                       None),
    ('Hotels',             ['hotel', 'astor house'],                       None),
    ('Land & Property',    ['land', 'realty', 'fonciere', 'immobiliere'], 'Real Estate'),
    ('Retail & Stores',    ['stores', 'watson', 'lane crawford',
                             'kelly & walsh', 'hall & holtz'],            None),
    ('Entertainment',      ['greyhound', 'racquet', 'recreation',
                             'race course', 'stadium', 'luna park'],      None),
    ('Printing & Media',   ['mercury', 'press', 'printing'],              None),
    ('Bonds & Preferences', ['bond', 'preference', 'debenture'],          None),
]

# Fallback: broad sector -> default fine sector
_BROAD_TO_FINE_DEFAULT = {
    'Banking':          'Banks',
    'Shipping':         'Steam Navigation',
    'Insurance':        'General Insurance',
    'Docks & Wharves':  'Docks & Shipbuilding',
    'Mining':           'General Mining',
    'Plantations':      'Rubber Plantations',
    'Cotton':           'Cotton & Textiles',
    'Industrial':       'General Miscellaneous',
    'Real Estate':      'Land & Property',
    'Miscellaneous':    'General Miscellaneous',
}


def classify_subsector(name, broad_sector, sector_raw):
    """Classify a company into one of ~25 fine-grained subsectors.

    Uses keyword matching on the company name and raw sector label,
    with broad_sector used to restrict certain rules and provide defaults.
    """
    name_low = name.lower() if name else ''
    raw_low = str(sector_raw).lower() if sector_raw else ''
    search_text = name_low + ' | ' + raw_low

    for fine, keywords, broad_filter in _SUBSECTOR_RULES:
        if broad_filter is not None and broad_sector != broad_filter:
            continue
        for kw in keywords:
            if kw in search_text:
                return fine

    return _BROAD_TO_FINE_DEFAULT.get(broad_sector, 'General Miscellaneous')


# -- Helpers ---------------------------------------------------------------

def safe_float(val):
    """Convert a cell value to float, returning None for non-numeric."""
    if val is None:
        return None
    if isinstance(val, (int, float)):
        return None if np.isnan(val) else float(val)
    s = str(val).strip().upper()
    if s in ('', 'N.A', 'N.A.', 'NA', '-', '--', 'N/A', 'NIL', 'NAN'):
        return None
    try:
        return float(s.replace(',', ''))
    except ValueError:
        return None


# Regex matching US$ column markers: US$, U$, U.S.$, Value (U$), US $, etc.
USD_RE = re.compile(r'U\.?S?\.?\s?\$')

# Price-category header patterns, searched in priority order
PRICE_PATTERNS = [
    'closing quotation',   # 1870-1876
    'cash quotation',      # 1877-~1910
    'last business done',  # 1911-1930
    'closing today',       # 1931-1940  ("This Week-Closing Today")
    'this week',           # 1931-1940
    'closing auction',     # 1931-1940
    'latest sales',        # 1938-1940
    'opening price',       # fallback
    'opening cash',        # fallback
]


# -- Step 1: Column Detection ---------------------------------------------

def detect_columns(df, year):
    """
    Dynamically detect column positions for a single year's sheet.

    Returns dict with keys:
        header_row, data_start, price_usd, shares, paidup_usd, dividend_usd
    or None if the sheet cannot be parsed.
    """
    n_scan = min(9, len(df))
    n_cols = len(df.columns)

    # 1. Find the row containing "Sector" (always in cols 0-2)
    header_row = None
    for i in range(n_scan):
        for j in range(min(3, n_cols)):
            if str(df.iloc[i, j]).strip().lower() == 'sector':
                header_row = i
                break
        if header_row is not None:
            break
    if header_row is None:
        return None

    # 2. Find data-start row (first row after header_row with a numeric id)
    data_start = None
    for i in range(header_row + 1, min(len(df), header_row + 7)):
        v = df.iloc[i, 1]
        try:
            if pd.notna(v) and float(v) > 0:
                data_start = i
                break
        except (ValueError, TypeError):
            pass
    if data_start is None:
        data_start = header_row + 2

    # 3. Scan ALL rows 0..data_start-1 for column markers
    scan_end = data_start

    # -- US$ marker columns --
    usd_cols = set()
    for i in range(scan_end):
        for j in range(n_cols):
            val = str(df.iloc[i, j]).strip()
            if USD_RE.search(val):
                usd_cols.add(j)
    usd_cols = sorted(usd_cols)

    def nearest_usd_after(col):
        """Return the first US$ column at or after `col`."""
        if col is None:
            return None
        for c in usd_cols:
            if c >= col:
                return c
        return None

    # -- Price US$ column --
    # Strategy: try pattern-based detection first.  If the result lands outside
    # the "price zone" (cols 3-20), fall back to picking the best US$ column
    # in that zone (prefer Cash/Sales/Latest over Buyers/Sellers/Nom).
    price_hint = None
    for pat in PRICE_PATTERNS:
        for i in range(scan_end):
            for j in range(3, min(n_cols, 40)):
                if pat in str(df.iloc[i, j]).strip().lower():
                    price_hint = j
                    break
            if price_hint is not None:
                break
        if price_hint is not None:
            break
    price_usd = nearest_usd_after(price_hint)

    # If the pattern match landed outside the price zone, fall back
    if price_usd is None or price_usd > 20:
        price_zone = [c for c in usd_cols if 3 <= c <= 20]
        if price_zone:
            # Prefer columns whose header contains cash/sales/latest
            preferred = None
            for c in price_zone:
                for i in range(scan_end):
                    val = str(df.iloc[i, c]).strip().lower()
                    if any(t in val for t in ['cash', 'sales', 'latest']):
                        preferred = c
                        break
                if preferred is not None:
                    break
            price_usd = preferred if preferred else price_zone[0]
        elif usd_cols:
            price_usd = usd_cols[0]
        else:
            price_usd = None

    # -- Shares outstanding column --
    shares_col = None
    for i in range(scan_end):
        for j in range(3, n_cols):
            val = str(df.iloc[i, j]).strip().lower()
            if (val in ('no', 'no.')
                    or ('no of shares' in val and 'total' not in val)
                    or 'issued capital' in val):
                shares_col = j
                break
        if shares_col is not None:
            break

    # -- Paid-up US$ column --
    paidup_hint = None
    for i in range(scan_end):
        for j in range(3, n_cols):
            val = str(df.iloc[i, j]).strip().lower()
            if 'paid up' in val or 'paid-up' in val:
                paidup_hint = j
                break
        if paidup_hint is not None:
            break
    paidup_usd = nearest_usd_after(paidup_hint)

    # -- Dividend US$ column (prefer "Last Dividend") --
    div_hint = None
    # Priority 1: "Last Dividend" or "Dividend Last Year"
    for i in range(scan_end):
        for j in range(3, n_cols):
            val = str(df.iloc[i, j]).strip().lower()
            if 'last dividend' in val or 'dividend last' in val:
                div_hint = j
                break
        if div_hint is not None:
            break
    # Priority 2: generic "Dividend" (not interim/bonus/for-the-year)
    if div_hint is None:
        for i in range(scan_end):
            for j in range(3, n_cols):
                val = str(df.iloc[i, j]).strip().lower()
                if ('dividend' in val and
                        not any(q in val for q in
                                ['for the year', 'interim', 'bonus'])):
                    div_hint = j
                    break
            if div_hint is not None:
                break
    # Priority 3: any "Dividend"
    if div_hint is None:
        for i in range(scan_end):
            for j in range(3, n_cols):
                if 'dividend' in str(df.iloc[i, j]).strip().lower():
                    div_hint = j
                    break
            if div_hint is not None:
                break

    div_usd = nearest_usd_after(div_hint)

    # Sanity: dividend column must differ from price and paid-up columns
    if div_usd is not None and div_usd in (price_usd, paidup_usd):
        try:
            idx = usd_cols.index(div_usd)
            if idx + 1 < len(usd_cols):
                div_usd = usd_cols[idx + 1]
        except ValueError:
            pass

    return {
        'header_row': header_row,
        'data_start': data_start,
        'price_usd': price_usd,
        'shares': shares_col,
        'paidup_usd': paidup_usd,
        'dividend_usd': div_usd,
    }


# -- Step 2: Data Extraction ----------------------------------------------

def extract_year_data(df, cols, year):
    """
    Extract company records from a single year's sheet.

    Returns list of dicts with keys:
        year, sector_raw, sector, unique_id, name,
        price_usd, shares, paidup_usd, dividend_usd
    """
    records = []
    data_start = cols['data_start']
    current_sector_raw = None

    for idx in range(data_start, len(df)):
        row = df.iloc[idx]

        # Forward-fill sector from col 0
        sec_val = row.iloc[0]
        if pd.notna(sec_val) and str(sec_val).strip():
            current_sector_raw = str(sec_val).strip()

        # Require a valid numeric unique_id in col 1
        uid = safe_float(row.iloc[1])
        if uid is None:
            continue
        uid = int(uid)

        name = str(row.iloc[2]).strip() if pd.notna(row.iloc[2]) else ''

        def col_val(key):
            c = cols[key]
            if c is None or c >= len(row):
                return None
            return safe_float(row.iloc[c])

        price = col_val('price_usd')
        shares = col_val('shares')
        paidup = col_val('paidup_usd')
        dividend = col_val('dividend_usd')

        sector = harmonize_sector(current_sector_raw)
        if sector is None:
            continue
        sector_fine = classify_subsector(name, sector, current_sector_raw)

        records.append({
            'year': year,
            'sector_raw': current_sector_raw,
            'sector': sector,
            'sector_fine': sector_fine,
            'unique_id': uid,
            'name': name,
            'price_usd': price,
            'shares': shares,
            'paidup_usd': paidup,
            'dividend_usd': dividend,
        })

    return records


# -- Step 3: Return Computation --------------------------------------------

def compute_returns(all_records):
    """
    For each company present in consecutive years t-1 and t, compute:
        cap_ap   = (Price_t - Price_{t-1}) / Price_{t-1}
        income   = Dividend_t / Price_{t-1}   (0 if missing)
        total    = cap_ap + income

    Returns a DataFrame of company-level annual returns.
    """
    # Build lookup: (year, unique_id) -> record  (prefer records with prices)
    lookup = {}
    for rec in all_records:
        key = (rec['year'], rec['unique_id'])
        if key not in lookup:
            lookup[key] = rec
        elif rec['price_usd'] is not None and lookup[key]['price_usd'] is None:
            lookup[key] = rec

    years = sorted(set(r['year'] for r in all_records))
    results = []

    for year in years:
        prev_year = year - 1
        cur_ids = {r['unique_id'] for r in all_records if r['year'] == year}

        for uid in cur_ids:
            cur_key = (year, uid)
            prev_key = (prev_year, uid)
            if prev_key not in lookup or cur_key not in lookup:
                continue

            cur = lookup[cur_key]
            prev = lookup[prev_key]

            p_t = cur['price_usd']
            p_tm1 = prev['price_usd']
            if p_t is None or p_tm1 is None or p_tm1 <= 0:
                continue

            cap_ap = (p_t - p_tm1) / p_tm1

            div_t = cur['dividend_usd']
            income = (div_t / p_tm1) if (div_t is not None and div_t > 0) else 0.0
            total_ret = cap_ap + income

            shares_tm1 = prev['shares']
            mktcap_tm1 = (p_tm1 * shares_tm1
                          if shares_tm1 is not None and shares_tm1 > 0
                          else None)

            outlier = (cap_ap > 5.0 or cap_ap < -0.95
                       or total_ret > 5.0 or total_ret < -0.95)

            results.append({
                'year': year,
                'unique_id': uid,
                'name': cur['name'],
                'sector': cur['sector'],
                'sector_fine': cur['sector_fine'],
                'price_t': p_t,
                'price_tm1': p_tm1,
                'shares_tm1': shares_tm1,
                'dividend_usd': div_t,
                'cap_ap': cap_ap,
                'income': income,
                'total_return': total_ret,
                'mktcap_tm1': mktcap_tm1,
                'outlier_flag': outlier,
            })

    return pd.DataFrame(results)


# -- Step 4: Industry Aggregation ------------------------------------------

def aggregate_industry(returns_df):
    """
    Compute EW and VW industry-level returns per sector per year.
    """
    results = []
    for (year, sector), grp in returns_df.groupby(['year', 'sector']):
        n = len(grp)

        # Equal-weighted
        ew_cap = grp['cap_ap'].mean()
        ew_inc = grp['income'].mean()
        ew_tot = grp['total_return'].mean()

        # Value-weighted (by beginning-of-period market cap)
        vw_sub = grp.dropna(subset=['mktcap_tm1'])
        vw_sub = vw_sub[vw_sub['mktcap_tm1'] > 0]
        if len(vw_sub) > 0:
            w_total = vw_sub['mktcap_tm1'].sum()
            w = vw_sub['mktcap_tm1'] / w_total
            vw_cap = (w * vw_sub['cap_ap']).sum()
            vw_inc = (w * vw_sub['income']).sum()
            vw_tot = (w * vw_sub['total_return']).sum()
        else:
            vw_cap = vw_inc = vw_tot = np.nan

        results.append({
            'year': year,
            'sector': sector,
            'n_companies': n,
            'ew_cap_ap': ew_cap,
            'ew_income': ew_inc,
            'ew_total': ew_tot,
            'vw_cap_ap': vw_cap,
            'vw_income': vw_inc,
            'vw_total': vw_tot,
        })

    return pd.DataFrame(results)


# -- Step 5: Validation ----------------------------------------------------

def compute_aggregate(returns_df):
    """Compute all-industry aggregate EW and VW returns per year."""
    rows = []
    for year, grp in returns_df.groupby('year'):
        ew_cap = grp['cap_ap'].mean()
        ew_inc = grp['income'].mean()
        ew_tot = grp['total_return'].mean()

        vw_sub = grp.dropna(subset=['mktcap_tm1'])
        vw_sub = vw_sub[vw_sub['mktcap_tm1'] > 0]
        if len(vw_sub) > 0:
            w = vw_sub['mktcap_tm1'] / vw_sub['mktcap_tm1'].sum()
            vw_cap = (w * vw_sub['cap_ap']).sum()
            vw_inc = (w * vw_sub['income']).sum()
            vw_tot = (w * vw_sub['total_return']).sum()
        else:
            vw_cap = vw_inc = vw_tot = np.nan

        rows.append({
            'year': year,
            'computed_ew_cap_ap': ew_cap,
            'computed_ew_income': ew_inc,
            'computed_ew_total': ew_tot,
            'computed_vw_cap_ap': vw_cap,
            'computed_vw_income': vw_inc,
            'computed_vw_total': vw_tot,
        })
    return pd.DataFrame(rows)


def validate(returns_df):
    """Compare computed aggregate with Shanghai.csv and print diagnostics."""
    agg = compute_aggregate(returns_df)

    if not os.path.exists(VALIDATION_FILE):
        print("\n  Shanghai.csv not found -- skipping validation")
        return agg

    shanghai = pd.read_csv(VALIDATION_FILE)
    # Parse year from "Dec-YYYY" format
    shanghai['year'] = shanghai.iloc[:, 0].apply(
        lambda x: int(str(x).split('-')[1]) if '-' in str(x) else None
    )
    shanghai = shanghai.dropna(subset=['year'])
    shanghai['year'] = shanghai['year'].astype(int)
    shanghai = shanghai.rename(columns={
        'Shanghai EW Cap Ap': 'ref_ew_cap_ap',
        'Shanghai EW Inc':    'ref_ew_income',
        'Shanghai EW TR':     'ref_ew_total',
        'Shanghai VW Cap Ap': 'ref_vw_cap_ap',
        'Shanghai VW Inc':    'ref_vw_income',
        'Shanghai VW TR':     'ref_vw_total',
    })

    merged = agg.merge(
        shanghai[['year', 'ref_ew_cap_ap', 'ref_ew_income', 'ref_ew_total',
                  'ref_vw_cap_ap', 'ref_vw_income', 'ref_vw_total']],
        on='year', how='left',
    )

    overlap = merged.dropna(subset=['ref_ew_cap_ap', 'computed_ew_cap_ap'])
    if len(overlap) >= 3:
        pairs = [
            ('EW Cap Ap', 'computed_ew_cap_ap', 'ref_ew_cap_ap'),
            ('EW Income', 'computed_ew_income', 'ref_ew_income'),
            ('EW Total ', 'computed_ew_total',  'ref_ew_total'),
            ('VW Cap Ap', 'computed_vw_cap_ap', 'ref_vw_cap_ap'),
            ('VW Income', 'computed_vw_income', 'ref_vw_income'),
            ('VW Total ', 'computed_vw_total',  'ref_vw_total'),
        ]
        print(f"\n  Validation vs Shanghai.csv  ({len(overlap)} overlapping years)")
        print(f"  {'Metric':<10s}  {'Corr':>7s}  {'MAE':>8s}")
        print(f"  {'-'*10}  {'-'*7}  {'-'*8}")
        for label, comp_col, ref_col in pairs:
            ov = overlap.dropna(subset=[comp_col, ref_col])
            if len(ov) >= 3:
                corr = ov[comp_col].corr(ov[ref_col])
                mae = (ov[comp_col] - ov[ref_col]).abs().mean()
                print(f"  {label:<10s}  {corr:>7.4f}  {mae:>8.4f}")
            else:
                print(f"  {label:<10s}  insufficient overlap")

        # Print year-by-year comparison for EW Cap Ap
        print(f"\n  Year-by-year EW Cap Ap comparison (first/last 5 years):")
        print(f"  {'Year':>4s}  {'Computed':>9s}  {'Reference':>9s}  {'Diff':>9s}")
        print(f"  {'-'*4}  {'-'*9}  {'-'*9}  {'-'*9}")
        show = pd.concat([overlap.head(5), overlap.tail(5)]).drop_duplicates()
        for _, r in show.iterrows():
            diff = r['computed_ew_cap_ap'] - r['ref_ew_cap_ap']
            print(f"  {int(r['year']):>4d}  {r['computed_ew_cap_ap']:>+9.4f}  "
                  f"{r['ref_ew_cap_ap']:>+9.4f}  {diff:>+9.4f}")

    return merged


# -- Main ------------------------------------------------------------------

def main():
    print("=" * 72)
    print("  Shanghai Stock Exchange Industry Return Indexes (1870-1940)")
    print("=" * 72)

    # Load workbook
    print(f"\n  Loading {os.path.basename(XLS_FILE)} ...")
    xls = pd.ExcelFile(XLS_FILE)
    years = sorted([int(s) for s in xls.sheet_names if s.isdigit()])
    print(f"  Found {len(years)} sheets: {years[0]}--{years[-1]}")

    # -- Step 1 & 2: Column detection + data extraction --
    print(f"\n  -- Column Detection --")
    print(f"  {'Year':>4s}  {'Hdr':>3s}  {'Data':>4s}  {'Price':>5s}  "
          f"{'Shrs':>5s}  {'PdUp':>5s}  {'Div':>5s}  Status")
    print(f"  {'----'}  {'---'}  {'----'}  {'-----'}  "
          f"{'-----'}  {'-----'}  {'-----'}  {'--------------------'}")

    all_records = []
    col_info = {}
    sector_raw_all = set()

    for year in years:
        df = pd.read_excel(xls, sheet_name=str(year), header=None)
        cols = detect_columns(df, year)

        if cols is None:
            print(f"  {year:>4d}  FAILED -- no 'Sector' header")
            continue

        col_info[year] = cols
        status = 'OK'
        if cols['price_usd'] is None:
            status = 'WARN: no price col'

        def _s(v):
            return str(v) if v is not None else '  --'

        print(f"  {year:>4d}  {cols['header_row']:>3d}  {cols['data_start']:>4d}  "
              f"{_s(cols['price_usd']):>5s}  {_s(cols['shares']):>5s}  "
              f"{_s(cols['paidup_usd']):>5s}  {_s(cols['dividend_usd']):>5s}  "
              f"{status}")

        records = extract_year_data(df, cols, year)
        all_records.extend(records)
        for r in records:
            sector_raw_all.add(r['sector_raw'])

    # Sector mapping summary (broad)
    print(f"\n  -- Sector Mapping (Broad) --")
    for raw in sorted(sector_raw_all, key=lambda x: str(x)):
        harmonized = harmonize_sector(raw)
        print(f"    {str(raw):<40s} -> {harmonized}")

    # Fine-sector mapping summary (show each company's fine sector)
    print(f"\n  -- Sector Mapping (Fine) --")
    seen_fine = {}  # (name, sector_fine) -> count
    for r in all_records:
        key = (r['name'], r['sector_fine'])
        seen_fine[key] = seen_fine.get(key, 0) + 1
    for (name, fine), cnt in sorted(seen_fine.items(),
                                     key=lambda x: (x[0][1], x[0][0])):
        print(f"    {name[:40]:<40s} -> {fine}")

    n_total = len(all_records)
    n_priced = sum(1 for r in all_records if r['price_usd'] is not None)
    n_shares = sum(1 for r in all_records if r['shares'] is not None)
    print(f"\n  Company-year observations: {n_total}")
    print(f"    with price:  {n_priced}")
    print(f"    with shares: {n_shares}")

    # -- Step 3: Returns --
    print(f"\n  -- Computing Returns --")
    returns_df = compute_returns(all_records)
    print(f"  Company-year return observations: {len(returns_df)}")

    if len(returns_df) == 0:
        print("  ERROR: No returns computed -- check column detection above")
        return

    outliers = returns_df[returns_df['outlier_flag']]
    if len(outliers) > 0:
        print(f"  Outliers (|cap_ap|>500% or total<-95%): {len(outliers)}")
        for _, o in outliers.head(20).iterrows():
            print(f"    {o['year']:.0f}  id={o['unique_id']:.0f}  "
                  f"{o['name'][:30]:<30s}  "
                  f"cap_ap={o['cap_ap']:+.1%}  inc={o['income']:.1%}  "
                  f"tot={o['total_return']:+.1%}")
        if len(outliers) > 20:
            print(f"    ... and {len(outliers) - 20} more")

    # -- Step 4: Industry aggregation (fine-grained ~25 sectors) --
    print(f"\n  -- Industry Aggregation (Fine Sectors) --")
    # Temporarily rename sector_fine -> sector for aggregate_industry()
    fine_df = returns_df.copy()
    fine_df['sector'] = fine_df['sector_fine']
    industry_df = aggregate_industry(fine_df)

    print(f"\n  {'Sector':<25s}  {'Yrs':>4s}  {'AvgN':>5s}  "
          f"{'EW TR':>8s}  {'VW TR':>8s}")
    print(f"  {'-'*25}  {'-'*4}  {'-'*5}  {'-'*8}  {'-'*8}")
    for sector in sorted(industry_df['sector'].unique()):
        sec = industry_df[industry_df['sector'] == sector]
        avg_n = sec['n_companies'].mean()
        avg_ew = sec['ew_total'].mean()
        vw_vals = sec['vw_total'].dropna()
        avg_vw = vw_vals.mean() if len(vw_vals) > 0 else np.nan
        vw_str = f'{avg_vw:>+8.4f}' if not np.isnan(avg_vw) else '     N/A'
        print(f"  {sector:<25s}  {len(sec):>4d}  {avg_n:>5.1f}  "
              f"{avg_ew:>+8.4f}  {vw_str}")

    # -- Step 5: Validation & output --
    print(f"\n  -- Validation --")
    validation_df = validate(returns_df)

    # Write outputs
    print(f"\n  -- Output Files --")
    industry_df.to_csv(OUTPUT_INDUSTRY, index=False, float_format='%.6f')
    print(f"  {os.path.basename(OUTPUT_INDUSTRY)}: "
          f"{len(industry_df)} rows, "
          f"{industry_df['sector'].nunique()} fine sectors, "
          f"{industry_df['year'].nunique()} years")

    # Company returns CSV includes both broad sector and sector_fine
    returns_df.to_csv(OUTPUT_COMPANY, index=False, float_format='%.6f')
    print(f"  {os.path.basename(OUTPUT_COMPANY)}: {len(returns_df)} rows")

    validation_df.to_csv(OUTPUT_VALIDATION, index=False, float_format='%.6f')
    print(f"  {os.path.basename(OUTPUT_VALIDATION)}: {len(validation_df)} rows")

    print(f"\n  Done.")
    print("=" * 72)


if __name__ == '__main__':
    main()
