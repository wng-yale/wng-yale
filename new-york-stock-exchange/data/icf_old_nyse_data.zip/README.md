# ICF data — Old New York Stock Exchange 1815–1925

Downloaded 2026-08-18 from the Yale ICF page:
https://som.yale.edu/centers/international-center-for-finance/data/historical-financial-research-data/new-york-exchange

Folder structure mirrors the section headings on that page.

**Citation (per the site):** "Data made available through the International Center for Finance at Yale University."

Reference paper: Goetzmann, Ibbotson & Peng, "A new historical database for the NYSE
1815 to 1925: Performance and predictability," *Journal of Financial Markets*.

---

## Government Security Prices and Loans

Final data files were compiled from the raw newspaper files by (a) averaging the bid
and offer price, and (b) averaging previous and next prices when a newspaper was
missing or no price was listed.

### Final Data/
| File | Notes |
|---|---|
| Government Security Prices 1800-1835 and Description of Loans.doc | The site lists prices 1800–1835 and the loan descriptions as one link; it resolves to this single .doc |
| Government Security Prices 1843-1860.xls | Excel 97-2003 |

### Sources/
| File | Notes |
|---|---|
| Newspaper Sources 1800-1860.doc | Source newspapers behind the raw data |

### Raw Data/
| File |
|---|
| New York Price Current 1800-1817.xls |
| New York Shipping and Commercial List 1817-1829.xls |
| New York Shipping and Commercial List 1830-1835.xls |
| New York Commercial Advertiser 1843-1847.xls |
| New York Commercial Advertiser 1847-1859.xls |

---

## NYSE Data

### Annual Dividends 1825-1870/
| File | Notes |
|---|---|
| nyse-annual-dividend-1825-1870.xls | Excel 97-2003. Same file already present in `../Data/` |

### Monthly Prices 1815-1925/
| File | Notes |
|---|---|
| nyse-monthly-price-1815-1925-updated-2021-09-04-with-labels.csv | **Current version** (revised 2021) |
| UpdateNotes-2021-09-04 (revision note 2021).pdf | Revision note for the 2021 file |
| nyse-monthly-price-1815-1925-corrected-2020-08-20.csv | Prior version (revised 2020) |
| RevisionNotes-2020-08-20 (revision note 2020).pdf | Revision note for the 2020 file |

### Security Names/
| File | Notes |
|---|---|
| nyse-firms-1815-1925-updated-2021-09-04 (new).csv | Site's "Download new data" |
| nyse-security-name-id (old).rtf | Site's "Download old data" |

### Annual Series/
| File | Notes |
|---|---|
| oldNYSEannualseries (ver 2015).xls | **Excel 4.0 (BIFF4) format** — modern Excel may refuse to open it; see note below |

### Monthly Index/
| File | Notes |
|---|---|
| Price-Weighted-Index-Returns-2020-08-20.csv | Price-weighted index returns, 2020 revision |

---

## Notes on the downloads

1. **Mislabeled extensions on the server.** Four files are served with an extension that
   does not match their contents. They were renamed here to their true format:
   - `Price-Weighted-Index-Returns-2020-08-20` — served `.xls`, actually CSV
   - `nyse-monthly-price-1815-1925-corrected-2020-08-20` — served `.xls`, actually CSV
   - `nyse-firms-1815-1925-updated-2021-09-04` — served `.xls`, actually CSV
   - `nyse-security-name-id` — served `.txt`, actually RTF

2. **Duplicate link on the page.** The link labeled "Description of Loans for Security
   Prices Listed for the years 1843 - 1860 [.doc]" points at the *same* URL as the
   1843–1860 price spreadsheet, not at a separate description document. That description
   file does not appear to be reachable from the page; only the .xls was retrieved.

3. **Excel 4.0 file.** `oldNYSEannualseries (ver 2015).xls` is BIFF4. If Excel blocks it,
   open with LibreOffice, or in R: `readxl` will not read BIFF4 — convert first with
   `libreoffice --headless --convert-to xlsx`.

4. **Overlap with `../Data/`.** The parent `Data/` folder already contains local working
   copies of the monthly price files, the annual dividend file, and the index returns.
   The copies here are the pristine as-published versions.
